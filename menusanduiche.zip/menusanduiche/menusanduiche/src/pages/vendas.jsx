import React from 'react';

// Componente para a página do submenu
const Venda = () => (
  <div>
    <h1>Página Venda</h1>
    <p>Esta é a página do Venda.</p>
  </div>
);

export default Venda;

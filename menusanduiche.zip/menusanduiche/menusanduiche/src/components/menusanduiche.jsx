import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../style/dropdowmenu.css';

const Menusanduiche = () => {
  const [isOpen, setIsOpen] = useState(false); // Estado para controlar a abertura do menu
  const [openSubmenu, setOpenSubmenu] = useState(null); // Estado para controlar o submenu aberto

  // Função para alternar a abertura do menu
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  // Função para alternar o submenu aberto
  const toggleSubmenu = (submenu) => {
    setOpenSubmenu(openSubmenu === submenu ? null : submenu);
  };

  // Função para fechar o menu e o submenu
  const closeMenu = () => {
    setIsOpen(false);
    setOpenSubmenu(null);
  };

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <button className="menu-button" onClick={toggleMenu}>
        &#9776; {/* Ícone do menu sanduíche */}
      </button>
      {isOpen && (
        <div className="menu-content">
          <div className="menu-item" onClick={() => toggleSubmenu('gerenciar')}>
            Gerenciar
            {openSubmenu === 'gerenciar' && (
              <div className="submenu">
                <Link to="/clientes" onClick={closeMenu}>Clientes</Link>
                <Link to="/funcionarios" onClick={closeMenu}>Funcionários</Link>
                <Link to="/produtos" onClick={closeMenu}>Produtos</Link>
              </div>
            )}
          </div>
          <div className="menu-item" onClick={() => toggleSubmenu('consultar')}>
            Realizar Consulta
            {openSubmenu === 'consultar' && (
              <div className="submenu">
                <Link to="/agenda" onClick={closeMenu}>Agenda</Link>
              </div>
            )}
          </div>
          <div className="menu-item" onClick={() => toggleSubmenu('relatorio')}>
            Gerar Relatório
            {openSubmenu === 'relatorio' && (
              <div className="submenu">
                <Link to="/vendas" onClick={closeMenu}>Vendas</Link>
                <Link to="/relatorio-produtos" onClick={closeMenu}>Produtos</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
};

export default Menusanduiche;

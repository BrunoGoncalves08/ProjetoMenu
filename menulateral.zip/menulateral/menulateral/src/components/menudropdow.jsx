import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../style/dropdowmenu.css';

const Menudropdown = () => {
  const [openMenu, setOpenMenu] = useState(null); // Estado para controlar o menu aberto

  // Função para alternar o menu aberto
  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  // Função para fechar o menu
  const closeMenu = () => {
    setOpenMenu(null);
  };

  return (
    <div className="sidebar">
      <div className="menu-item" onClick={() => toggleMenu('gerenciar')}>
        Gerenciar
        {openMenu === 'gerenciar' && (
          <div className="submenu">
            <Link to="/clientes" onClick={closeMenu}>Clientes</Link>
            <Link to="/funcionarios" onClick={closeMenu}>Funcionários</Link>
            <Link to="/produtos" onClick={closeMenu}>Produtos</Link>
          </div>
        )}
      </div>
      <div className="menu-item" onClick={() => toggleMenu('consultar')}>
        Realizar Consulta
        {openMenu === 'consultar' && (
          <div className="submenu">
            <Link to="/agenda" onClick={closeMenu}>Agenda</Link>
          </div>
        )}
      </div>
      <div className="menu-item" onClick={() => toggleMenu('relatorio')}>
        Gerar Relatório
        {openMenu === 'relatorio' && (
          <div className="submenu">
            <Link to="/vendas" onClick={closeMenu}>Vendas</Link>
            <Link to="/relatorio-produtos" onClick={closeMenu}>Produtos</Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default Menudropdown;

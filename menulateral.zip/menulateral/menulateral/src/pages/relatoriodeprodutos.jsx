import React from 'react';

// Componente para a página do submenu
const RelatorioProduto = () => (
  <div>
    <h1>Página RelatorioProduto</h1>
    <p>Esta é a página do RelatorioProduto.</p>
  </div>
);

export default RelatorioProduto;

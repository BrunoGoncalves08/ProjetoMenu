import React, { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import Menudropdown from './components/menudropdow';

// Carregamento preguiçoso das páginas
const Home = lazy(() => import('./pages/home'));
const Cliente = lazy(() => import('./pages/clientes'));
const Funcionario = lazy(() => import('./pages/funcionario'));
const Produto = lazy(() => import('./pages/produto'));
const Agenda = lazy(() => import('./pages/agenda'));
const Venda = lazy(() => import('./pages/vendas'));
const RelatorioProduto = lazy(() => import('./pages/relatoriodeprodutos'));

const App = () => (
  
    <div className="app-container">
      <Menudropdown />
      <div className="content">
        <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/clientes" element={<Cliente />} />
            <Route path="/funcionarios" element={<Funcionario />} />
            <Route path="/produtos" element={<Produto />} />
            <Route path="/agenda" element={<Agenda />} />
            <Route path="/vendas" element={<Venda />} />
            <Route path="/relatorio-produtos" element={<RelatorioProduto />} />
          </Routes>
        </Suspense>
      </div>
    </div>
  
);

export default App;

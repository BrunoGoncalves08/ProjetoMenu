import React, { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import Menudropdown from './assets/components/menudropdow';

// Carregamento  das páginas
const Home = lazy(() => import('./assets/pages/home'));
const Cliente = lazy(() => import('./assets/pages/clientes'));
const Funcionario = lazy(() => import('./assets/pages/funcionario'));
const Produto = lazy(() => import('./assets/pages/produto'));
const Agenda = lazy(() => import('./assets/pages/agenda'));
const Venda = lazy(() => import('./assets/pages/vendas'));
const RelatorioProduto = lazy(() => import('./assets/pages/relatoriodeprodutos'));

const App = () => (
  
    <div>
      <Menudropdown />
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/clientes" element={<Cliente />} />
          <Route path="/funcionarios" element={<Funcionario />} />
          <Route path="/produtos" element={<Produto />} />
          <Route path="/agenda" element={<Agenda />} />
          <Route path="/vendas" element={<Venda />} />
          <Route path="/relatorio-produtos" element={<RelatorioProduto />} />
        </Routes>
      </Suspense>
    </div>
  
);

export default App;

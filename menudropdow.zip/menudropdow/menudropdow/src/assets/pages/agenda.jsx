import React from 'react';

// Componente para a página do submenu
const Agenda = () => (
  <div>
    <h1>Página Agenda</h1>
    <p>Esta é a página do Agenda.</p>
  </div>
);

export default Agenda;

import React from 'react';

// Componente para a página inicial
const Home = () => (
  <div>
    <h1>Página Inicial</h1>
    <p>Bem-vindo à página inicial!</p>
  </div>
);

export default Home;

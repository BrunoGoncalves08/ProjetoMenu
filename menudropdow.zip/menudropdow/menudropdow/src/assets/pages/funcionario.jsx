import React from 'react';

// Componente para a página do submenu
const Funcionario = () => (
  <div>
    <h1>Página Sub Funcionario</h1>
    <p>Esta é a página do Funcionario.</p>
  </div>
);

export default Funcionario;

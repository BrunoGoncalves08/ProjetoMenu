import React from 'react';

// Componente para a página do submenu
const Cliente = () => (
  <div>
    <h1>Página Cliente</h1>
    <p>Esta é a página do Cliente.</p>
  </div>
);

export default Cliente;

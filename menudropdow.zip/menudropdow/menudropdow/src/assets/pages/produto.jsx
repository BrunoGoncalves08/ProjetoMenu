import React from 'react';

// Componente para a página do submenu
const Produto = () => (
  <div>
    <h1>Página Sub Produto</h1>
    <p>Esta é a página do Produto.</p>
  </div>
);

export default Produto;
